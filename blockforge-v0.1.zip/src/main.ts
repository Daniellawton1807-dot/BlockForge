import * as THREE from "three";
import "./style.css";

type BlockId = 0 | 1 | 2 | 3;
type Block = { id: BlockId; mesh: THREE.Mesh };

const WORLD_X = 48;
const WORLD_Z = 48;
const WORLD_Y = 24;
const REACH = 7;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87bdf0);
scene.fog = new THREE.Fog(0x87bdf0, 35, 95);

const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.05, 150);
camera.position.set(24, 12, 24);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.querySelector("#app")!.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xcce7ff, 0x3b2e20, 1.7);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(30, 55, 15);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
scene.add(sun);

const materials: Record<BlockId, THREE.MeshStandardMaterial> = {
  0: new THREE.MeshStandardMaterial({ color: 0xffffff }),
  1: new THREE.MeshStandardMaterial({ color: 0x5bbd45, roughness: 1 }),
  2: new THREE.MeshStandardMaterial({ color: 0x8b5a35, roughness: 1 }),
  3: new THREE.MeshStandardMaterial({ color: 0x777b82, roughness: 1 })
};

const blocks: Block[] = [];
const occupied = new Map<string, Block>();
const cube = new THREE.BoxGeometry(1, 1, 1);

const key = (x: number, y: number, z: number) => `${x},${y},${z}`;

function terrainHeight(x: number, z: number) {
  const n =
    Math.sin(x * 0.19) * 1.8 +
    Math.sin(z * 0.14) * 1.5 +
    Math.sin((x + z) * 0.08) * 2.1;
  return Math.max(2, Math.min(13, Math.floor(7 + n)));
}

function addBlock(x: number, y: number, z: number, id: BlockId) {
  if (id === 0 || y < 0 || y >= WORLD_Y) return;
  const k = key(x, y, z);
  if (occupied.has(k)) return;

  const mesh = new THREE.Mesh(cube, materials[id]);
  mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.block = { x, y, z };
  scene.add(mesh);

  const block = { id, mesh };
  blocks.push(block);
  occupied.set(k, block);
}

function removeBlock(x: number, y: number, z: number) {
  const b = occupied.get(key(x, y, z));
  if (!b) return;
  scene.remove(b.mesh);
  occupied.delete(key(x, y, z));
}

for (let x = 0; x < WORLD_X; x++) {
  for (let z = 0; z < WORLD_Z; z++) {
    const h = terrainHeight(x, z);
    for (let y = 0; y <= h; y++) {
      const id: BlockId = y === h ? 1 : y >= h - 2 ? 2 : 3;
      addBlock(x, y, z, id);
    }
  }
}

// A small spawn clearing.
for (let x = 20; x < 28; x++) {
  for (let z = 20; z < 28; z++) {
    const h = terrainHeight(x, z);
    removeBlock(x, h, z);
    addBlock(x, h, z, 1);
  }
}

const outline = new THREE.LineSegments(
  new THREE.EdgesGeometry(cube),
  new THREE.LineBasicMaterial({ color: 0xffffff })
);
outline.scale.setScalar(1.01);
outline.visible = false;
scene.add(outline);

const player = {
  height: 1.8,
  radius: 0.32,
  velocity: new THREE.Vector3(),
  onGround: false
};

const keys = new Set<string>();
let yaw = Math.PI;
let pitch = -0.12;
let locked = false;

addEventListener("keydown", e => {
  keys.add(e.code);
  if (e.code === "Space") e.preventDefault();
});
addEventListener("keyup", e => keys.delete(e.code));

renderer.domElement.addEventListener("click", () => {
  renderer.domElement.requestPointerLock();
});

addEventListener("pointerlockchange", () => {
  locked = document.pointerLockElement === renderer.domElement;
  document.querySelector("#start")!.textContent = locked ? "" : "CLICK TO PLAY";
});

addEventListener("mousemove", e => {
  if (!locked) return;
  yaw -= e.movementX * 0.0022;
  pitch -= e.movementY * 0.0022;
  pitch = Math.max(-Math.PI / 2 + 0.05, Math.min(Math.PI / 2 - 0.05, pitch));
});

const raycaster = new THREE.Raycaster();

function targetBlock() {
  raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  const hits = raycaster.intersectObjects(blocks.map(b => b.mesh), false);
  return hits.find(h => h.distance <= REACH);
}

addEventListener("mousedown", e => {
  if (!locked) return;
  const hit = targetBlock();
  if (!hit) return;

  const data = hit.object.userData.block as { x: number; y: number; z: number };

  if (e.button === 0) {
    // Don't let the player delete the ground beneath the spawn by accident.
    if (data.y > 0) removeBlock(data.x, data.y, data.z);
  }

  if (e.button === 2) {
    const normal = hit.face!.normal.clone();
    const p = new THREE.Vector3(data.x, data.y, data.z).add(normal);
    const x = Math.floor(p.x), y = Math.floor(p.y), z = Math.floor(p.z);
    if (x >= 0 && x < WORLD_X && z >= 0 && z < WORLD_Z && y >= 0 && y < WORLD_Y) {
      addBlock(x, y, z, 1);
    }
  }
});
addEventListener("contextmenu", e => e.preventDefault());

function solidAt(x: number, y: number, z: number) {
  return occupied.has(key(Math.floor(x), Math.floor(y), Math.floor(z)));
}

function collides(pos: THREE.Vector3) {
  const minX = pos.x - player.radius;
  const maxX = pos.x + player.radius;
  const minY = pos.y;
  const maxY = pos.y + player.height;
  const minZ = pos.z - player.radius;
  const maxZ = pos.z + player.radius;

  for (let x = Math.floor(minX); x <= Math.floor(maxX); x++)
    for (let y = Math.floor(minY); y <= Math.floor(maxY); y++)
      for (let z = Math.floor(minZ); z <= Math.floor(maxZ); z++)
        if (solidAt(x, y, z)) return true;
  return false;
}

function moveAxis(pos: THREE.Vector3, axis: "x" | "y" | "z", amount: number) {
  if (amount === 0) return;
  const steps = Math.max(1, Math.ceil(Math.abs(amount) / 0.08));
  const step = amount / steps;
  for (let i = 0; i < steps; i++) {
    pos[axis] += step;
    if (collides(pos)) {
      pos[axis] -= step;
      if (axis === "y") {
        if (amount < 0) player.onGround = true;
        player.velocity.y = 0;
      }
      return;
    }
  }
}

let last = performance.now();
function animate(now: number) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;

  const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
  const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  const wish = new THREE.Vector3();

  if (keys.has("KeyW")) wish.add(forward);
  if (keys.has("KeyS")) wish.sub(forward);
  if (keys.has("KeyD")) wish.add(right);
  if (keys.has("KeyA")) wish.sub(right);
  if (wish.lengthSq()) wish.normalize();

  const speed = keys.has("ShiftLeft") ? 7.5 : 5.2;
  player.velocity.x = THREE.MathUtils.damp(player.velocity.x, wish.x * speed, 12, dt);
  player.velocity.z = THREE.MathUtils.damp(player.velocity.z, wish.z * speed, 12, dt);

  if (keys.has("Space") && player.onGround) {
    player.velocity.y = 8;
    player.onGround = false;
  }
  player.velocity.y -= 22 * dt;
  player.onGround = false;

  moveAxis(camera.position, "x", player.velocity.x * dt);
  moveAxis(camera.position, "z", player.velocity.z * dt);
  moveAxis(camera.position, "y", player.velocity.y * dt);

  camera.rotation.order = "YXZ";
  camera.rotation.y = yaw;
  camera.rotation.x = pitch;

  const hit = targetBlock();
  if (hit) {
    const data = hit.object.userData.block as { x: number; y: number; z: number };
    outline.position.set(data.x + 0.5, data.y + 0.5, data.z + 0.5);
    outline.visible = true;
  } else {
    outline.visible = false;
  }

  document.querySelector("#status")!.textContent =
    `${Math.round(camera.position.x)}, ${Math.round(camera.position.y)}, ${Math.round(camera.position.z)} · ${blocks.length} blocks`;

  renderer.render(scene, camera);
}
requestAnimationFrame(animate);

addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
