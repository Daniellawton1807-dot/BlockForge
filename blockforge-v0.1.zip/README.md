# BlockForge

An original browser-based voxel sandbox.

## Development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Controls

- WASD — move
- Mouse — look
- Space — jump
- Shift — sprint
- Left click — break block
- Right click — place grass block

## Roadmap

- Chunk meshing / face culling
- Inventory and hotbar
- Multiple block types
- Better terrain and caves
- Trees and ores
- World save/load
- Lighting
- Mobs
- Multiplayer server
- Authentication and persistent worlds
